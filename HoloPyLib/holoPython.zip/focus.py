# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import math
import numpy as np
from numpy.fft import fft2 as np_fft2
from numpy.fft import ifft2 as np_ifft2
from numpy.fft import fftshift as np_fftshift
from numpy.fft import ifftshift as np_ifftshift

import cupy as cp
from cupy.fft import fft2, ifft2, fftshift, ifftshift
from cupyx import jit
from cupyx.scipy import ndimage as cp_ndimage
import typeHolo
from traitement_holo import *




def focus_sum_square_of_laplacien(d_volume_IN, d_focus_OUT, sumSize):
    
    sizeX, sizeY, sizeZ = cp.shape(d_volume_IN)

    #allocation intensity plane
    plane = cp.zeros(shape = (sizeX, sizeY), dtype = cp.float32)

    #si sumSize est pair rajouter 1
    sumSize = (sumSize //2 )+1
    #allocation plan de convolution (carré de 1.0 de taille sumSize)
    convolve_plane = cp.full(fill_value=1.0, dtype=cp.float32, shape=(sumSize, sumSize))

    for p in range(sizeZ):
        plane = intensite(d_volume_IN[:,:,p])
        cp_ndimage.laplace(plane, plane)
        plane = cp.square(plane)
        cp_ndimage.convolve(plane, convolve_plane, output = d_focus_OUT[:,:,p], mode = 'reflect')
