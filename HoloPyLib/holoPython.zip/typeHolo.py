# -*- coding: utf-8 -*-

class info_Holo:
    nb_pix_X = 0
    nb_pix_Y = 0
    pixSize = 0.0
    magnification = 0.0
    lambdaMilieu = 0.0


