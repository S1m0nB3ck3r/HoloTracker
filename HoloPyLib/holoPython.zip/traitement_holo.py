# -*- coding: utf-8 -*-

import os
from PIL import Image
import numpy as np
import cupy as cp
import time
import math

os.chdir(r'C:\TRAVAIL\developpement\imagesHolo\bactos 12_05_2022\25bact m100um 1')

def affichage(plan):

    if isinstance(plan, cp.ndarray):
        h_plan = cp.asnumpy(plan)
        min = h_plan.min()
        max = h_plan.max()
        img = Image.fromarray((h_plan - min) * 255 / (max - min))

    else:
        min = plan.min()
        max = plan.max()
        img = Image.fromarray((plan - min) * 255 / (max - min))
    
    img.show(title = "plan")
    img.close()


@cp.fuse()
def div_holo(A, B):
    if (B!=0.0):
        C = A/B
    else:
        C = 0.0
    return C

def module(planComplex):
    if isinstance(planComplex, cp.ndarray):
        return(cp.sqrt(cp.square(cp.real(planComplex)) + cp.square(cp.imag(planComplex))))
    else:
        return(np.sqrt(np.square(np.real(planComplex)) + np.square(np.imag(planComplex))))

def intensite(planComplex):
    if isinstance(planComplex, cp.ndarray):
        return(cp.square(cp.real(planComplex)) + cp.square(cp.imag(planComplex)))
    else:
        return(np.square(np.real(planComplex)) + np.square(np.imag(planComplex)))

def phase(planComplex):
    if isinstance(planComplex, cp.ndarray):
        return(cp.arctan(cp.imag(planComplex) /cp.real(planComplex)))
    else:
        return(np.arctan(np.imag(planComplex) /np.real(planComplex)))

def calc_holo_moyen(sizeX, sizeY, dirPath, extension):
    
    holo_m = np.empty((sizeY,sizeX), dtype = int)
    nb_images_tot = len(os.listdir(dirPath))
    nb_images = 0
    start = time.time()

    for image in os.listdir(os.getcwd()):
        nb_images +=1
        img= Image.open(image)
        holo = np.asarray(img)
        sx = np.size(holo, axis=0)
        sy = np.size(holo, axis=1)
        offsetX = (sx - sizeX)//2
        offsetY = (sy - sizeY)//2
        holo = holo[offsetX:offsetX+sizeX:1, offsetY:offsetY+sizeY:1]
        holo_m += holo
        img.close()
        print(round(100* nb_images/nb_images_tot, 1), "% Done")

    print("Nombre d'images: ", nb_images)
    print("Temps d'execution", time.time() - start)

    holo_m = holo_m / nb_images

    return(holo_m)


