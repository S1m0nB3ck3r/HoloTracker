# -*- coding: utf-8 -*-

import cupy as cp
import numpy as np
from cupyx import jit
import time
import os
from PIL import Image
from traitement_holo import *
import propagation as propag
import focus
import typeHolo
from cupyx.scipy.fft import *
from typeHolo import *
import math
import time
# repertoire courant
path = r'C:\TRAVAIL\developpement\imagesHolo\bactos 12_05_2022\25bact m100um 1'

nb_plan = 100

infoHolo = info_Holo()
infoHolo.lambdaMilieu = 660e-9 / 1.33
infoHolo.magnification = 40.0
infoHolo.nb_pix_X = 1024
infoHolo.nb_pix_Y = 1024
infoHolo.pixSize = 5e-6

sizeX = infoHolo.nb_pix_X
sizeY = infoHolo.nb_pix_Y
sumSize = 11

#allocations
h_holo = np.zeros(shape = (sizeX, sizeY), dtype = cp.float32)
d_holo = cp.zeros(shape = (sizeX, sizeY), dtype = cp.float32)
d_fft_holo = cp.zeros(shape = (sizeX, sizeY), dtype = cp.complex64)
d_fft_holo_propag = cp.zeros(shape = (sizeX, sizeY), dtype = cp.complex64)
d_holo_propag = cp.zeros(shape = (sizeX, sizeY), dtype = cp.float32)
d_KERNEL = cp.zeros(shape = (sizeX, sizeY), dtype = cp.complex64)
d_volume = cp.zeros(shape = (sizeX, sizeY, nb_plan), dtype = cp.complex64)
d_volume_focus = cp.zeros(shape = (sizeX, sizeY, nb_plan), dtype = cp.float32)

#calcul holo moyen
h_mean_holo = calc_holo_moyen(sizeX, sizeY, path, 'bmp')
d_mean_holo = cp.asarray(h_mean_holo)
img_mean_holo = Image.fromarray(h_mean_holo)
img_mean_holo.show()

#pour chaque hologramme du répertoire
for image in os.listdir(path):
    
    img= Image.open(image)
    h_holo = np.asarray(img)
    sx = np.size(h_holo, axis=0)
    sy = np.size(h_holo, axis=1)
    offsetX = (sx - sizeX)//2
    offsetY = (sy - sizeY)//2
    h_holo = h_holo[offsetX:offsetX+sizeX:1, offsetY:offsetY+sizeY:1]
    h_holo = np.subtract(h_holo, h_mean_holo)
    min = h_holo.min()
    max = h_holo.max()
    h_holo =(h_holo - min) * 255 / (max - min)
    h_holo = np.sqrt(h_holo)
    min = h_holo.min()
    max = h_holo.max()
    img = Image.fromarray((h_holo - min) * 255 / (max - min))
    img.show(title = "holo")

    d_holo = cp.asarray(h_holo)

    #calcul du volume propagé
    startTime = time.perf_counter()
    propag.volume_propag(d_holo, d_fft_holo, d_KERNEL, d_fft_holo_propag, d_volume,
        infoHolo.lambdaMilieu, infoHolo.magnification, infoHolo.pixSize, infoHolo.nb_pix_X, infoHolo.nb_pix_Y, 1e-6, nb_plan)
    endTime = time.perf_counter()
    print(endTime-startTime)

    #calcul du focus sur tout le volume
    startTime = time.perf_counter()
    focus.focus_sum_square_of_laplacien(d_volume, d_volume_focus, sumSize)
    print(endTime-startTime)


    for p in range(nb_plan):
        affichage(d_volume_focus[:,:,p])


    h_volume = cp.asnumpy(d_volume)

   
    module_holo = intensite(d_volume[:,:,0])
    affichage(module_holo)
    phase_holo = phase(d_volume[:,:,0])
    affichage(phase_holo)
    module_holo = intensite(d_volume[:,:,nb_plan-1])
    affichage(module_holo)
    phase_holo = phase(d_volume[:,:,nb_plan-1])
    affichage(phase_holo)










