# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import math
import numpy as np
from numpy.fft import fft2 as np_fft2
from numpy.fft import ifft2 as np_ifft2
from numpy.fft import fftshift as np_fftshift
from numpy.fft import ifftshift as np_ifftshift

import cupy as cp
from cupy.fft import fft2, ifft2, fftshift, ifftshift
from cupyx import jit
from cupyx.scipy import ndimage as cp_ndimage
import typeHolo
from traitement_holo import *

@jit.rawkernel()
def d_calc_phase(d_plan_complex, d_phase, size_x, size_y):
    index = jit.blockIdx.x * jit.blockDim.x + jit.threadIdx.x
    sizeXY = size_x * size_y

    jj = index // size_x
    ii = index - jj * size_x

    if (ii < size_x and jj < size_y):
        cplx = cp.complex64(d_plan_complex[ii, jj])
        r = cp.real(cplx)
        if (r == 0.0):
            d_phase[ii, jj] = 0.0
        elif(cp.real(cplx) > 0.0):
            d_phase[ii, jj] = cp.arctan(cp.imag(cplx) / cp.real(cplx))
        else:
            d_phase[ii, jj] = cp.pi + cp.arctan(cp.imag(cplx) / cp.real(cplx))

       

@jit.rawkernel()
def d_calc_kernel_angular_spectrum_jit(d_KERNEL, lambda_milieu, magnification, pixSize, nb_pix_X, nb_pix_Y, distance):

    index = jit.blockIdx.x * jit.blockDim.x + jit.threadIdx.x
    sizeXY = nb_pix_X * nb_pix_Y

    jj = index // nb_pix_X
    ii = index - jj * nb_pix_X

    if (ii < nb_pix_X and jj < nb_pix_Y):
        du = magnification / (pixSize * cp.float32(nb_pix_X))
        dv = magnification / (pixSize * cp.float32(nb_pix_Y))

        offset_u = nb_pix_X//2
        offset_v = nb_pix_Y//2

        U = ( cp.int32(ii) - cp.int32(offset_u) )*du
        V = ( cp.int32(jj) - cp.int32(offset_v) )*dv
        
        arg = 1.0 - cp.square(lambda_milieu * U) - cp.square(lambda_milieu *V )
        
        if(arg>0):
            d_KERNEL[ii, jj] = cp.exp(2 * 1j * cp.pi * distance * cp.sqrt(arg) / lambda_milieu)
        else:
            d_KERNEL[ii, jj] = 0+0j

#propagation
def propag(d_HOLO, d_FFT_HOLO, d_KERNEL, d_FFT_HOLO_PROPAG, d_HOLO_PROPAG,
lambda_milieu, magnification, pixSize, nb_pix_X, nb_pix_Y, distance):

    nthread = 1024
    nBlock = math.ceil(nb_pix_X * nb_pix_Y // nthread)

    d_FFT_HOLO = fftshift(fft2(d_HOLO, norm = 'forward'))
    d_calc_kernel_angular_spectrum_jit[nBlock, nthread](d_KERNEL, lambda_milieu, magnification, pixSize, nb_pix_X, nb_pix_Y, distance)
    d_FFT_HOLO_PROPAG = d_FFT_HOLO * d_KERNEL
    d_HOLO_PROPAG = fft2(fftshift(d_FFT_HOLO_PROPAG), norm = 'backward')



#calcul volume
def volume_propag(d_HOLO, d_FFT_HOLO, d_KERNEL, d_FFT_HOLO_PROPAG, d_HOLO_VOLUME_PROPAG,
lambda_milieu, magnification, pixSize, nb_pix_X, nb_pix_Y, pasPropag, nbPropag):

    nthread = 1024
    nBlock = math.ceil(nb_pix_X * nb_pix_Y // nthread)

    d_FFT_HOLO = fftshift(fft2(d_HOLO, norm = 'forward'))
    for i in range(nbPropag):
        distance = (i + 1)* pasPropag
        d_calc_kernel_angular_spectrum_jit[nBlock, nthread](d_KERNEL, lambda_milieu, magnification, pixSize, nb_pix_X, nb_pix_Y, distance)
        d_FFT_HOLO_PROPAG = d_FFT_HOLO * d_KERNEL
        d_HOLO_VOLUME_PROPAG[:,:,i] = fft2(fftshift(d_FFT_HOLO_PROPAG), norm = 'backward')


